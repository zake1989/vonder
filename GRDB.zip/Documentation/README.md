The main documentation is available in [README.md](../README.md#documentation).
