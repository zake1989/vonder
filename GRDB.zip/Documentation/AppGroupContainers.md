Sharing a Database in an App Group Container
============================================

This guide [has moved](https://swiftpackageindex.com/groue/grdb.swift/documentation/grdb/databasesharing).
