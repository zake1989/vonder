# FetchedRecordsController

FetchedRecordsController has been removed in GRDB 5.

See [Database Observation](https://swiftpackageindex.com/groue/grdb.swift/documentation/grdb/databaseobservation) for other ways to observe the database.
