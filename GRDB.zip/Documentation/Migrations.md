# Migrations

This guide [has moved](https://swiftpackageindex.com/groue/grdb.swift/documentation/grdb/migrations).
