# Full-Text Search

Search a corpus of textual documents.

## Overview

Please refer to the [Full-Text Search](https://github.com/groue/GRDB.swift/blob/master/Documentation/FullTextSearch.md) guide. It also describes how to enable support for the FTS5 engine.

## Topics

### Full-Text Engines

- ``FTS3``
- ``FTS4``
- ``FTS5``
