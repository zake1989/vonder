#if canImport(Combine)
/// A namespace for database Combine publishers.
@available(iOS 13, macOS 10.15, tvOS 13, watchOS 6, *)
public enum DatabasePublishers { }
#endif
