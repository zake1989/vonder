#ifndef getThreadsCount_h
#define getThreadsCount_h

/// Returns the number of mach threads, or -1 in case of error.
int getThreadsCount(void);

#endif /* getThreadsCount_h */
